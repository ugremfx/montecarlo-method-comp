function [ELave,ELvar] = metropolis(nsamples,lamda,alpha)
% Metropolis algorithm for random walk

cur_pos(nsamples,:) = -5 + 5*2.*rand(1,4); % Initial position

for ii = (nsamples-1):-1:1
    new_pos = -5 + 5*2.*rand(1,4); % Generate a new position. A pseudo random number from a uniform distribution between -1 and 1;
    p = abs(twoD_f(new_pos,lamda,alpha))^2/abs(twoD_f(cur_pos(ii,:),lamda,alpha))^2; % Calculate the new probability
    if p >= 1 % The new position is accepted
        cur_pos(ii,:) = new_pos; % Current position gets accepted
    elseif rand <= p % The new position is accepted with probability p
        cur_pos(ii,:) = new_pos; % select with prob p, othersiwe it is not selected
    else
        cur_pos(ii,:) = cur_pos(ii+1,:);
    end
    
end

r = sqrt((cur_pos(:,1)-cur_pos(:,3)).^2+(cur_pos(:,2)-cur_pos(:,4)).^2);

% Numerical version of EL
%psi = twoD_f(cur_pos,lamda,alpha);
% EL =  (-1/2*(twoD_2df(cur_pos,lamda,alpha,1)  + ...
%              twoD_2df(cur_pos,lamda,alpha,2)  + ...
%              twoD_2df(cur_pos,lamda,alpha,3)  + ...
%              twoD_2df(cur_pos,lamda,alpha,4)) + ...
%              (1/2*(sum(cur_pos.^2,2))         + ...
%              lamda./r).*psi)./psi; % The normalized EL/(hbar*omega)
         
%Analytical version
EL =  (-1/2*(twoD_2df(cur_pos,lamda,alpha,1)  + ...
             twoD_2df(cur_pos,lamda,alpha,2)  + ...
             twoD_2df(cur_pos,lamda,alpha,3)  + ...
             twoD_2df(cur_pos,lamda,alpha,4)) + ...
             (1/2*(sum(cur_pos.^2,2))         + ...
             lamda./r)); % The normalized EL/(hbar*omega)

ELave = mean(EL); % Average
ELvar = mean(EL.^2) - ELave^2; % Variance


end

