function sec_deriv = twoD_2df(z,lamda,alpha,derivflag)

% Numerical version
% h = 1e-8; % Step for finite difference approximation of second derivative
% 
% hz = h*[derivflag == 1, derivflag == 2, derivflag == 3 ,derivflag == 4];
% 
% fp1 = twoD_f(z+hz,lamda,alpha);
% fm1 = twoD_f(z-hz,lamda,alpha);
% f0  = twoD_f(z   ,lamda,alpha);
% 
% sec_deriv = (fp1-2*f0+fm1)./h^2; % Central second order derivative


%% Analytical version

x1 = z(:,1);
y1 = z(:,2);
x2 = z(:,3);
y2 = z(:,4);
r = sqrt((x1 - x2).^2 + (y1 - y2).^2);
a = alpha;
k = lamda;

if derivflag == 1 %x1
    
sec_deriv = (-1 + (x1 + (a*k*(x1 - x2))./(1 + a*r).^2 + ...
     (k*(-x1 + x2))./((1 + a*r).*r)).^2 - ...
   (a*k)./(1 + a*r).^2 - (k*(x1 - x2).^2)./((1 + a*r).* ...
     ((x1 - x2).^2 + (y1 - y2).^2).^(3/2)) - (a*k*(x1 - x2).^2)./...
    ((1 + a*r).^2.*((x1 - x2).^2 + (y1 - y2).^2)) + ...
   (2*a.^2*k*(x1 - x2).^2)./((1 + a*r).^3.*r)+k./((1 + a*r).*r));

elseif derivflag == 3 % x2
    
sec_deriv = (-1 + (x2 - (a*k*(x1 - x2))./(1 + a*r).^2 + ...
     (k*(x1 - x2))./((1 + a*r).*r)).^2 - ...
   (a*k)./(1 + a*r).^2 - (k*(x1 - x2).^2)./((1 + a*r).*...
     ((x1 - x2).^2 + (y1 - y2).^2).^(3/2)) - (a*k*(x1 - x2).^2)./...
    ((1 + a*r).^2.*((x1 - x2).^2 + (y1 - y2).^2)) + ...
   (2*a^2*k*(x1 - x2).^2)./((1 + a*r).^3.* r) + k./((1 + a*r).*r));
     
elseif derivflag == 2 % y1
sec_deriv =    (-1 - (a*k)./(1 + a*r).^2 +  k./((1 + a*r).*...
     r) - (k.*(y1 - y2).^2)./ ((1 + a.*r).*((x1 - x2).^2 + (y1 - y2).^2).^...
      (3/2)) - (a*k*(y1 - y2).^2)./((1 + a*r).^2.*((x1 - x2).^2 + (y1 - y2).^2)) + (2*a.^2*k*(y1 - y2).^2)./...
    ((1 + a*r).^3.* r) + (y1 + (a*k.*(y1 - y2))./(1 + a*r).^2 + ...
     (k*(-y1 + y2))./((1 + a*r).*r)).^2); 
    
elseif derivflag == 4 % y2

sec_deriv = (-1 - (a*k)./(1 + a*r).^2 + k./((1 + a*r).*...
     r) - (k*(y1 - y2).^2)./((1 + a*r).*((x1 - x2).^2 + (y1 - y2).^2).^...
      (3/2)) - (a*k.*(y1 - y2).^2)./((1 + a*r).^2.*((x1 - x2).^2 + (y1 - y2).^2)) + (2*a.^2*k*(y1 - y2).^2)./...
    ((1 + a*r).^3.*r) + (y1 + (a*k.*(y1 - y2))./(1 + a.*r).^2 + ...
     (k*(-y1 + y2))./((1 + a*r).*r)).^2); 

end


end