function f = twoD_f(z,lamda,alpha)

% Trial wave function 2 electrons in 2D
x1 = z(:,1);
y1 = z(:,2);
x2 = z(:,3);
y2 = z(:,4);

r = sqrt((x1-x2).^2+(y1-y2).^2);
f = exp(-(x1.^2+y1.^2+x2.^2+y2.^2)/2).*exp(lamda.*r./(1+alpha*r));

end