function [Elave_ave, ELvar_ave] = QMC(lamda,alpha)
% To calculate the average of averages and average of variances

no_steps = 1000; % No of steps for average of averages
nsamples = 300000; % n samples for metropolis loop

for ii = no_steps:-1:1
[ELave(ii),ELvar(ii)] = metropolis(nsamples,lamda,alpha);
end

Elave_ave = mean(ELave); % Average of averages
ELvar_ave = mean(ELvar);


