function [ELave,ELvar] = metropolis(nsamples,alpha)
% Metropolis algorithm for random walk

cur_pos = -5 + 5*2.*rand; % Initial position
EL = zeros(nsamples,1); % Initialization
pos_for_hist = zeros(nsamples,1);

for ii = nsamples:-1:1
    new_pos = -5 + 5*2.*rand; % Generate a new position. A pseudo random number from a uniform distribution between -1 and 1;
    p = abs(oneD_trial_f(new_pos,alpha))^2/abs(oneD_trial_f(cur_pos,alpha))^2; % Calculate the new probability
    if p >= 1 % The new position is accepted
        cur_pos = new_pos; % Current position gets accepted
    elseif p < 1 % The new position is accepted with probability p
        if rand <= p
           cur_pos = new_pos; % select with prob p, othersiwe it is not selected
        end
    end
    EL(ii) = alpha+cur_pos^2*(1/2-2*alpha^2); % The normalized EL/(hbar*omega)
    pos_for_hist(ii) = cur_pos; % Register position to make the histogram
end

%figure; 
%h = histfit(pos_for_hist,50); % Histrogram of points during random walk

ELave = mean(EL); % Average
ELvar = mean(EL.^2) - ELave^2; % Variance


end

