function [Elave_ave, ELvar_ave] = QMC(alpha)
% To calculate the average of averages and average of variances

no_steps = 100; % No of steps for average of averages
nsamples = 20000; % n samples for metropolis loop

for ii = no_steps:-1:1
[ELave(ii),ELvar(ii)] = metropolis(nsamples,alpha);
end

Elave_ave = mean(ELave); % Average of averages
ELvar_ave = mean(ELvar);


