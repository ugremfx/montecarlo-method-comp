function [xmin, golden] = golden(ax,bx,cx,tol,f)

%Given a function f, and given a bracketing triplet of abscissas ax, bx, cx (such that bx is
%between ax and cx, and f(bx) is less than both f(ax) and f(cx)), this routine performs
%a golden section search for the minimum, isolating it to a fractional precision of about
%tol. The abscissa of the minimum is returned as xmin, and the minimum function value
%is returned as golden, the returned function value.
%Parameters: The golden ratios.

% Reference: Numerical recipes The art of scientific computing, Chap. 10

R = 0.61803399;
C = 1 - R;


x0 = ax; %At any given time we will keep track of four points, x0,x1,x2,x3.
x3 = cx;
if(abs(cx-bx) > abs(bx-ax)) % then Make x0 to x1 the smaller segment,
    x1=bx;
    x2=bx+C*(cx-bx); %and fill in the new point to be tried.
else
    x2=bx;
    x1=bx-C*(bx-ax);
end
f1 = f(x1); %The initial function evaluations.
f2 = f(x2);

while(abs(x3-x0) > tol*(abs(x1)+abs(x2))) %then Do-while loop: we keep returning here.
    if(f2 < f1)%then One possible outcome,
        x0=x1; %its housekeeping,
        x1=x2;
        x2=R*x1+C*x3; % ==x3-R(x3-x1)
        f1=f2;
        f2=f(x2); %and a new function evaluation.
    else %The other outcome,
        x3=x2;
        x2=x1;
        x1=R*x2+C*x0; % ==x0+R(x2-x0)
        f2=f1;
        f1=f(x1); %and its new function evaluation.
    end
    % goto 1 Back to see if we are done.
end

if(f1 < f2) %then We are done. Output the best of the two current values.
    golden=f1;
    xmin=x1;
else
    golden=f2;
    xmin=x2;
end


end
