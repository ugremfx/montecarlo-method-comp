function f = oneD_trial_f(z,alpha)
% Trial wave function

f = exp(-alpha*z^2);

end