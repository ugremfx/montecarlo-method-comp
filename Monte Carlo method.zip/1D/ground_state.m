

[xmin, golden] = golden(0,1,2,1e-4,@ QMC); % Find the ground state energy by varying alpha with the golden section search algorithm

alpha = 0.1:0.05:1; % Interval for alpha for the plot
Elave_ave = alpha;
ELvar_ave = alpha;

for ii = 1:length(alpha)
[Elave_ave(ii), ELvar_ave(ii)] = QMC(alpha(ii)); % Evaluate the average of energy for different alpha values
end


%% Plot ground energe level with respect to alpha
figure
yyaxis left
plot(alpha,Elave_ave)
xlabel('\alpha')
ylabel('\langleE_L\rangle')
yyaxis right
plot(alpha,ELvar_ave)
xlabel('\alpha')
ylabel('Var(E_L)')
title(['$\min \frac{E}{\hbar\omega} = $',' ',num2str(golden,3),' at $\alpha = $',' ',num2str(xmin,3)],'interpreter','latex');

%% Evaluate the analitycal expression of H:

a = 1/2;
z = -3:0.1:3;

expH = (sqrt(a)*z.*exp(-2*a*z.^2).*(4*a*z.^2 + 8*a - 7))./(8*sqrt(pi)*erf(sqrt(a)*z)) + ((8*a - 1)*erf(sqrt(2)*sqrt(a)*z))./(16*sqrt(2)*erf(sqrt(a).*z)); % https://www.wolframalpha.com/input/?i=%281%2F64+%284+e%5E%28-2+a+z%5E2%29+z+%28-7+%2B+4+a+%282+%2B+z%5E2%29%29+%2B+%28%28-1+%2B+8+a%29+sqrt%282+%CF%80%29+erf%28sqrt%282%29+sqrt%28a%29+z%29%29%2Fsqrt%28a%29%29%29%2F%28%28sqrt%28%CF%80%29+erf%28sqrt%28a%29+z%29%29%2F%282+sqrt%28a%29%29%29

figure
plot(z,expH)
xlabel('z')
ylabel('$\langle H\rangle$','interpreter','latex')
legend('$\langle H\rangle$ for $\alpha=1/2$','interpreter','latex')